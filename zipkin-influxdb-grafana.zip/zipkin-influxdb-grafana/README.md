##TODO
# Statistics 没有Message
# PTC / count 不显示数据


#### kafka性能指标
- Broker
- Partition
  * Message size
  * Message number
  * Message from which producer

- Producer / Consumer

-> 消息体大小 In/out
-> 每秒消息数 In/out
-> 每秒MB 
-> duration


    kafka.messages_in
    kafka.net.bytes_in
    kafka.net.bytes_out
    kafka.net.bytes_rejected
    kafka.replication.isr_expands
    kafka.replication.isr_shrinks
    kafka.replication.leader_elections
    kafka.replication.unclean_leader_elections
    kafka.request.fetch.failed
    kafka.request.fetch.time.99percentile
    kafka.request.fetch.time.avg
    kafka.request.handler.avg.idle.pct
    kafka.request.metadata.time.99percentile
    kafka.request.metadata.time.avg
    kafka.request.offsets.time.99percentile
    kafka.request.offsets.time.avg
    kafka.request.produce.failed
    kafka.request.produce.time.99percentile
    kafka.request.produce.time.avg
    kafka.request.update_metadata.time.99percentile
    kafka.request.update_metadata.time.avg

./kafka-producer-perf-test.sh 
--topic 指定topic
--num-records	指定生产数据量
--throughtput	指定吞吐量
--record-size   record数据大小


./kafka-consumer-perf-test.sh
--topic 指定topic
--threads 指定线程数
--messages 指定消费数据条数
--broker-list kafka broker列表

-- 请求之前时间间隔


--producer-props key=value	指定producer配置

TODO - jmeter plugin add size of request/ response

---
http://jmeter.apache.org/usermanual/realtime-results.html
https://www.cnblogs.com/benben-wu/p/10650410.html

线程数/用户相关指标
test.minAT-Min active threads：最小活跃线程数
test.maxAT-Max active threads：最大活跃线程数
test.meanAT-Mean active threads：活跃线程数
test.startedT-Started threads：启动线程数
test.endedT-Finished threads：结束线程数
响应时间指标
.ok.count：采样器的成功响应数
.h.count：每秒点击数
.ok.min：采样器成功最短响应时间
.ok.max：采样器成功最长响应时间
.ok.avg：采样器成功平均响应时间
.ok.pct：采样器成功响应百分比
.ko.count：采样器失败响应数
.ko.min：采样器失败的响应最短时间
.ko.max：采样称失败最长响应时间
.ko.avg：采样器失败平均响应时间
.ko.pct：采样器失败响应百分比
.a.count：采样器响应数（ok.count和ko.count的总和）
.a.min：采样器最小响应时间（ok.count和ko.count的最小值）
.a.max：采样器最大响应时间（ok.count和ko.count的最大值）
.a.avg：采样器平均响应时间（ok.count和ko.count的平均值）
.a.pct：采样器响应百分比（根据和失败样本的总数计算）
Backend Listener的默认百分位设置为“90;95;99”，即百分位数为90％，95％和99％。
Graphite使用点（“.”）去拆分的元素，这可能与十进制百分位值混淆。JMeter转换任何此类值，用下划线（“ - ”）替换点（“.”）。例如，“99.9 ”变为“99_9 ”
默认情况下，JMeter发送在samplerName“all”下累计的所有采样器的指标。 如果配置了 BackendListenerSamplersList，那么JMeter还会发送匹配样本名称的指标，前提是配置 summaryOnly=true