package org.benjamin.zipkin;

import org.apache.commons.io.FileUtils;
import org.benjamin.manager.FileManager;
import org.benjamin.zipkin.moudule.Span;
import org.junit.Test;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class TestZipkinClientAPI {
//    @Test
//    public void testGet() {
//        ZipkinClientAPI client = new ZipkinClientAPI();
//        String str = client.get();
////        System.out.println(str);
//
//        List<Span> spans = client.getSpans(str);
//        client.getSpanByPCT(spans, 30);
//    }
//    @Test
//    public void testGetCallBack() {
//        ZipkinClientAPI client = new ZipkinClientAPI();
//        String str = client.get("traces", "", "", 1000 * 60 * 60);
//        System.out.println(str);
//    }
//
//    @Test
//    public void testAllSpan() throws IOException {
//        String allSpansString = FileUtils.readFileToString(FileManager.getFile("all.json"), "UTF-8");
//        ZipkinClientAPI client = new ZipkinClientAPI();
//        List<Span> spans = client.getSpans(allSpansString);
//        spans.forEach(span -> System.out.println(span.getId() + "-->" + span.getDuration()));
//
////        client.getStatistics(spans);
//        System.out.println("PCT 99 --> " + client.getSpanByPCT(spans, 99));
//        System.out.println("PCT 95 --> " + client.getSpanByPCT(spans, 95));
//        System.out.println("PCT 90 --> " + client.getSpanByPCT(spans, 90));
//    }
//
//    @Test
//    public void testAllSpanTag() throws IOException {
//        String allSpansString = FileUtils.readFileToString(FileManager.getFile("kafka.json"), "UTF-8");
//        ZipkinClientAPI client = new ZipkinClientAPI();
//        List<Span> spans = client.getSpansOrderByTag(allSpansString, "offset");
//        spans.forEach(span -> System.out.println(span.getId() + "-->" + span.getDuration()));
//
////        client.getStatistics(spans);
//        System.out.println("PCT 99 --> " + client.getSpanByPCT(spans, "offset", 99));
//        System.out.println("PCT 95 --> " + client.getSpanByPCT(spans, "offset", 95));
//        System.out.println("PCT 90 --> " + client.getSpanByPCT(spans, "offset", 90));
//    }
//    @Test
//    public void testAllSpanTagCount() throws IOException {
//        String allSpansString = FileUtils.readFileToString(FileManager.getFile("kafka.json"), "UTF-8");
//        ZipkinClientAPI client = new ZipkinClientAPI();
//        Map<String, Long> counts = client.countSpansByTag(allSpansString, "partition");
//
//        counts.forEach((key, value) -> System.out.println("Key-" + key + ", Value-" + value));
//    }
//
//    @Test
//    public void testAllSpanTagStatistics() throws IOException {
//        String allSpansString = FileUtils.readFileToString(FileManager.getFile("kafka.json"), "UTF-8");
//        ZipkinClientAPI client = new ZipkinClientAPI();
//        List<Span> spans = client.getSpans(allSpansString);
////        client.getDurationStatisticsByTag(spans, "partition");
//
//        Map<String, Map<String, Map<String, Map<String, Object>>>> statistics = client.regroupSpans(spans, "kafka.topic", "content.size", Arrays.asList(90, 95, 99));
//        statistics.forEach((topic, topicMap) -> {
//            System.out.println("Topic -> " + topic);
//            topicMap.forEach((kind, kindMap) -> {
//                System.out.println("Kind -- > " + kind);
//                kindMap.forEach((statistic, statisticMap) -> {
//                    System.out.println("Statistic --- > " + statistic);
//                    statisticMap.forEach((key, value) -> {
//                        System.out.println("----------> Key - " + key + ": Value - " + value);
//                    });
//                });
//            });
//        });
//    }
//
//    @Test
//    public void testAllSpanTagStatistics2() throws IOException {
//        String allSpansString = FileUtils.readFileToString(FileManager.getFile("kafka.json"), "UTF-8");
//        ZipkinClientAPI client = new ZipkinClientAPI();
//        List<Span> spans = client.getSpans(allSpansString);
////        client.getDurationStatisticsByTag(spans, "partition");
//
//        Map<String, Map<String, Map<String, Map<String, Map<String, Object>>>>> brokerStatistics = client.regroupSpansUp(spans, "kafka.topic", "content.size", Arrays.asList(50, 90, 95, 99));
//
//        //Map<String, Map<String, Map<String, Map<String, Object>>>> statistics = client.regroupSpans(spans, "kafka.topic", "content.size", Arrays.asList(90, 95, 99));
//
//        brokerStatistics.forEach((broker, statistics) -> {
//            System.out.println("Broker:: -> " + broker);
//            statistics.forEach((topic, topicMap) -> {
//                System.out.println("Topic -> " + topic);
//                topicMap.forEach((kind, kindMap) -> {
//                    System.out.println("Kind -- > " + kind);
//                    kindMap.forEach((statistic, statisticMap) -> {
//                        System.out.println("Statistic --- > " + statistic);
//                        statisticMap.forEach((key, value) -> {
//                            System.out.println("----------> Key - " + key + ": Value - " + value);
//                        });
//                    });
//                });
//            });
//
//        });
//
//    }
//
//    @Test
//    public void testServiceNameSpanTagStatistics() throws IOException {
//        String allSpansString = FileUtils.readFileToString(FileManager.getFile("kafka.json"), "UTF-8");
//        ZipkinClientAPI client = new ZipkinClientAPI();
//        List<Span> spans = client.getSpans(allSpansString);
////        client.getDurationStatisticsByTag(spans, "partition");
//
//        Map<String, Map<String, Map<String, Map<String, Map<String, Object>>>>> brokerStatistics = client.regroupClientSpans(spans, "kafka.topic", "content.size", Arrays.asList(50, 90, 95, 99));
//
//        //Map<String, Map<String, Map<String, Map<String, Object>>>> statistics = client.regroupSpans(spans, "kafka.topic", "content.size", Arrays.asList(90, 95, 99));
//
//        brokerStatistics.forEach((broker, statistics) -> {
//            System.out.println("serviceName:: -> " + broker);
//            statistics.forEach((topic, topicMap) -> {
//                System.out.println("Topic -> " + topic);
//                topicMap.forEach((kind, kindMap) -> {
//                    System.out.println("Kind -- > " + kind);
//                    kindMap.forEach((statistic, statisticMap) -> {
//                        System.out.println("Statistic --- > " + statistic);
//                        statisticMap.forEach((key, value) -> {
//                            System.out.println("----------> Key - " + key + ": Value - " + value);
//                        });
//                    });
//                });
//            });
//
//        });
//
//    }
//
//
//    @Test
//    public void testPartitionSpanTagStatistics() throws IOException {
//        String allSpansString = FileUtils.readFileToString(FileManager.getFile("kafka.json"), "UTF-8");
//        ZipkinClientAPI client = new ZipkinClientAPI();
//        List<Span> spans = client.getSpans(allSpansString);
////        client.getDurationStatisticsByTag(spans, "partition");
//
//        Map<String, Map<String, Map<String, Map<String, Map<String, Object>>>>> brokerStatistics = client.regroupPartitionSpans(spans, "kafka.topic", "content.size", Arrays.asList(50, 90, 95, 99));
//
//        //Map<String, Map<String, Map<String, Map<String, Object>>>> statistics = client.regroupSpans(spans, "kafka.topic", "content.size", Arrays.asList(90, 95, 99));
//
//        brokerStatistics.forEach((broker, statistics) -> {
//            System.out.println("serviceName:: -> " + broker);
//            statistics.forEach((topic, topicMap) -> {
//                System.out.println("Topic -> " + topic);
//                topicMap.forEach((kind, kindMap) -> {
//                    System.out.println("Partition -- > " + kind);
//                    kindMap.forEach((statistic, statisticMap) -> {
//                        System.out.println("Statistic --- > " + statistic);
//                        statisticMap.forEach((key, value) -> {
//                            System.out.println("----------> Key - " + key + ": Value - " + value);
//                        });
//                    });
//                });
//            });
//
//        });
//
//    }
}
