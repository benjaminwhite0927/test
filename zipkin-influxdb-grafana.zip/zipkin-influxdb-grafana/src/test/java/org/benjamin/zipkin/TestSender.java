package org.benjamin.zipkin;

import org.apache.commons.io.FileUtils;
import org.benjamin.manager.FileManager;
import org.benjamin.manager.Sender;
import org.benjamin.zipkin.moudule.Span;

import java.io.IOException;
import java.util.List;

public class TestSender {
    public static void main(String[] args) throws IOException {
        String allSpansString = FileUtils.readFileToString(FileManager.getFile("kafka.json"), "UTF-8");
        ZipkinClientAPI client = new ZipkinClientAPI();
        List<Span> spans = client.getSpans(allSpansString);
        Sender sender = new Sender("kafka");
        sender.setup();
    }
}
