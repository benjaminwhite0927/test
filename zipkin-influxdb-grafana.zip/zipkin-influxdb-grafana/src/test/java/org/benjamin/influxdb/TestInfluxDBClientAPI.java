package org.benjamin.influxdb;

import org.junit.Test;

import java.util.Map;
import java.util.HashMap;
import java.util.Random;

public class TestInfluxDBClientAPI {
//    InfluxDBClientAPI client = new InfluxDBClientAPI("http://192.168.126.16:8086", "influxdb", "influxdb");
//
//    @Test
//    public void testCreateDataBase() {
//        client.createDatabase("testing");
//    }
//
//    @Test
//    public void testPost() {
//
//
//        for (int j = 0; j < 100; j++) {
//            Map<String, Object> parameters = new HashMap<>();
//            Random random = new Random();
//            //生成64-128内的随机数
//            int i = random.nextInt() * (128 - 64 + 1) + 64;
//
//            parameters.put("application", "kafka");
//            parameters.put("count", 353 + i);
//            i = random.nextInt() * (128 - 64 + 1) + 128;
//            parameters.put("countKO", i);
//            i = random.nextInt() * (1280 - 640 + 1) + 1280;
//            parameters.put("requestByte", 1000 + i);
//            i = random.nextInt() * (1280 - 640 + 1) + 1280;
//            parameters.put("responseByte", 1050 + i);
//            i = random.nextInt() * (1280 - 640 + 1) + 1280;
//            parameters.put("pct95", 1363.95 + i);
//            i = random.nextInt() * (1280 - 640 + 1) + 1280;
//            parameters.put("pct99", 1376.99 + i);
//            i = random.nextInt() * (1280 - 640 + 1) + 1280;
//            parameters.put("pct90", 360.0000000000001 + i);
//            this.write(parameters);
//
//            try {
//                Thread.sleep(2000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//            System.out.println(j + "--------");
//        }
//        client.close();
//    }
//
//
//    private void write(Map<String, Object> parameters ) {
//        client.writeData("zk", parameters);
//    }
}
