package org.benjamin.influxdb;

import org.apache.commons.lang3.StringUtils;
import org.benjamin.manager.ApplicationDataManager;
import org.benjamin.manager.ConfigurationManager;
import org.benjamin.zipkin.moudule.ZipkinConstant;
import org.influxdb.BatchOptions;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;
import org.influxdb.dto.Query;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.TimeUnit;

public class InfluxDBClientAPI {
    private InfluxDB influxDB;
    public static final String INFLUXDB_HOST = "influxdb.host";
    public static final String INFLUXDB_PORT = "influxdb.port";
    public static final String INFLUXDB_USERNAME = "influxdb.username";
    public static final String INFLUXDB_PASSWORD = "influxdb.password";

    public static final String INFLUXDB_RETENTION_POLICY_NAME_SUFFIX = "influxdb.retention.policy.name.suffix";
    public static final String INFLUXDB_RETENTION_POLICY_DURATION = "influxdb.retention.policy.duration";
    public static final String INFLUXDB_RETENTION_POLICY_REPLICATION = "influxdb.retention.policy.replication";

    private static final Logger log = LoggerFactory.getLogger(InfluxDBClientAPI.class);

    public InfluxDBClientAPI() {
        this("http://" + ConfigurationManager.getConfiguration(INFLUXDB_HOST) + ":" + ConfigurationManager.getConfiguration(INFLUXDB_PORT),
            ConfigurationManager.getConfiguration(INFLUXDB_USERNAME),
            ConfigurationManager.getConfiguration(INFLUXDB_PASSWORD));
    }

    private InfluxDBClientAPI(String serverURL, String username, String password) {
        influxDB = InfluxDBFactory.connect(serverURL, username, password);
        // Enable batch writes to get better performance.
        influxDB.enableBatch(BatchOptions.DEFAULTS);
    }

    public void init(String application) {
        this.createDatabase(application);
        this.createRetentionPolicy(application, application + ConfigurationManager.getConfiguration(INFLUXDB_RETENTION_POLICY_NAME_SUFFIX),
                ConfigurationManager.getConfiguration(INFLUXDB_RETENTION_POLICY_DURATION),
                Integer.valueOf(ConfigurationManager.getConfiguration(INFLUXDB_RETENTION_POLICY_REPLICATION)));
    }

    // TODO - add timestamp

    public void writeDoubleData(String application, String measurement, Map<String, Object> fields) {
        Point.Builder builder = Point.measurement(measurement).time(System.currentTimeMillis(), TimeUnit.MILLISECONDS);
        fields.forEach((key, value) -> {
            System.out.println("1--- Key-" + key + ": Value-" + value);
            if(value != null && !StringUtils.isEmpty(value.toString()) && !value.equals("null")) {
                if (ZipkinConstant.COUNT.equals(key)) {
                    System.out.println("Long--- Key-" + key + ": Value-" + value);
                    builder.addField(key, Long.valueOf(value.toString()));
                } else if(ApplicationDataManager.getInfluxDataOfApplication(application).get(ApplicationDataManager.DOUBLE_KEY).contains(key)
                    || key.startsWith(ZipkinConstant.PTC)) {
                    System.out.println("Double--- Key-" + key + ": Value-" + value);
                    builder.addField(key, Double.valueOf(value.toString()));
                } else {
                    System.out.println("String--- Key-" + key + ": Value-" + value);
                    builder.tag(key, value.toString());
                }
            }
        });
        influxDB.write(builder.build());
    }


    public void writeData(String application, String measurement, Map<String, Object> fields) {
        Point.Builder builder = Point.measurement(measurement).time(System.currentTimeMillis(), TimeUnit.MILLISECONDS);
        fields.forEach((key, value) -> {
            System.out.println("2-----------Key-" + key + ":Value-" + value);
            if(value != null && !StringUtils.isEmpty(value.toString()) && !value.equals("null")) {
                if(ApplicationDataManager.getInfluxDataOfApplication(application).get(ApplicationDataManager.STRING_KEY).contains(key)) {
                    System.out.println("String 1 -----------Key-" + key + ":Value-" + value);
                    builder.tag(key, value.toString());
                } else if(ApplicationDataManager.getInfluxDataOfApplication(application).get(ApplicationDataManager.DOUBLE_KEY).contains(key)
                        || key.startsWith(ZipkinConstant.PTC)) {
                    System.out.println("Double-----------Key-" + key + ":Value-" + value);
                    builder.addField(key, Double.valueOf(value.toString()));
                } else if (ApplicationDataManager.getInfluxDataOfApplication(application).get(ApplicationDataManager.LONG_KEY).contains(key)) {
                    System.out.println("Long-----------Key-" + key + ":Value-" + value);
                    builder.addField(key, Long.valueOf(value.toString()));
                } else {
                    System.out.println("String 2-----------Key-" + key + ":Value-" + value);
                    builder.tag(key, value.toString());
                }
            }

        });
        influxDB.write(builder.build());
    }

    public void close() {
        // Close it if your application is terminating or you are not using it anymore.
        influxDB.close();
    }

    private void createDatabase(String database) {
        if (!influxDB.databaseExists(database)) {
            influxDB.query(new Query("CREATE DATABASE " + database));
        }
        influxDB.setDatabase(database);
    }

    private void createRetentionPolicy(String databaseName, String retentionPolicyName, String duration, int replication) {
        influxDB.query(new Query("CREATE RETENTION POLICY " + retentionPolicyName
                + " ON " + databaseName + " DURATION " + duration + " REPLICATION " + replication + " DEFAULT"));
        influxDB.setRetentionPolicy(retentionPolicyName);
    }
}
