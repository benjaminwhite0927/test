package org.benjamin.manager;

import java.util.Properties;

public class ConfigurationManager {
    public static final String CONFIGURATION_FOLDER = "config";
    public static final String MANAGEMENT_PROPERTIES_FILE = "management";
    private static Properties configurations;

    public static String getConfiguration(String key) {
        if (configurations==null) {
            configurations = FileManager.loadAllProperties(CONFIGURATION_FOLDER + "/" + MANAGEMENT_PROPERTIES_FILE + ".properties");
        }
        return configurations.getProperty(key);
    }
}
