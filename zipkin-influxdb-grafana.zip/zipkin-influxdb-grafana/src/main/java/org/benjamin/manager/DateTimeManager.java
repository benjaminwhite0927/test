package org.benjamin.manager;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DateTimeManager {
    private static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";

    private static DateTimeFormatter getDateTimeFormatter() {
        return DateTimeFormatter.ofPattern(DATE_TIME_FORMAT)
                .withZone(ZoneId.systemDefault());
    }

    public static LocalDateTime stringToLocalDateTime(String str) {
        return LocalDateTime.parse(str, getDateTimeFormatter());
    }

    public static String localDateTimeToString(LocalDateTime localDateTime) {
        return localDateTime.format(getDateTimeFormatter());
    }

    //LocalDateTime -> Date
    public static Date localDateTimeToDate(LocalDateTime localDateTime) {
        return Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    //Date -> LocalDateTime
    public static LocalDateTime dateToLocalDateTime(Date date) {
        return Instant.ofEpochMilli(date.getTime()).atZone(ZoneId.systemDefault()).toLocalDateTime();
    }

    public static Date dateTimeStringToDate(String dateTimeString) {
        LocalDateTime localDateTime = stringToLocalDateTime(dateTimeString);
        return localDateTimeToDate(localDateTime);
    }

//    public static String generateTimeStamp(String dateString) {
//        Date date = new Date();
//        Calendar calendar = Calendar.getInstance();
//        calendar.setTime(date);
//
//        Matcher matcher = getDateFormatMatcher(dateString);
//        if(matcher.find()) {
//            int timeNum = Integer.valueOf(matcher.group(1));
//            TimeType timeType = TimeType.valueOf(matcher.group(2));
//            calendar.add(timeType.num, timeNum);
//        }
//        return localDateTimeToString(dateToLocalDateTime(calendar.getTime()));
//    }

    public static String getDateTimeFormat(String dateTimeString, String dateOperation) {
        Date date = dateTimeStringToDate(dateTimeString);
        return generateTimeStamp(date, dateOperation);
    }

    public static Calendar calendarOperation(Calendar calendar, String dateOperation) {
        return generateCalendar(calendar.getTime(), dateOperation);
    }

    public static long getTimeDifference(Date date, String dateOperation) {
        return date.getTime() - generateCalendar(date, dateOperation).getTimeInMillis();
    }

    public static long getTimeDifference(String dateOperation) {
        Date date = new Date();
        return date.getTime() - generateCalendar(date, dateOperation).getTimeInMillis();
    }

    public static String generateTimeStamp(String dateOperation) {
        return generateTimeStamp(new Date(), dateOperation);
    }


    public static String generateTimeStamp(Date date, String dateOperation) {
        Calendar calendar = generateCalendar(date, dateOperation);
        return localDateTimeToString(dateToLocalDateTime(calendar.getTime()));
    }

    private static Calendar generateCalendar(Date date, String dateOperation) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);

        Matcher matcher = getDateFormatMatcher(dateOperation);
        if (matcher.find()) {
            String num = matcher.group(1);
            int timeNum = 0;
            try {
                timeNum = Integer.valueOf(matcher.group(1));
            } catch (Exception e) {
                timeNum = (int) Calculator.executeExpression(num);
            }
//            int timeNum = Integer.valueOf(matcher.group(1));
//            System.out.println("Number - " + num);
//            int timeNum = (int)Calculator.executeExpression(num);
            TimeType timeType = TimeType.valueOf(matcher.group(2));
            calendar.add(timeType.num, timeNum);
        }
        return calendar;
    }

    public static int getIntervalType(String dateOperation) {
        Matcher matcher = getDateFormatMatcher(dateOperation);
        if (matcher.find()) {
            TimeType timeType = TimeType.valueOf(matcher.group(2));
            return timeType.num;
        }
        return 0;
    }
    public static int getIntervalNumber(String dateOperation) {
        Matcher matcher = getDateFormatMatcher(dateOperation);
        if (matcher.find()) {
            String num = matcher.group(1);
            int timeNum = 0;
            try {
                timeNum = Integer.valueOf(matcher.group(1));
            } catch (Exception e) {
                timeNum = (int) Calculator.executeExpression(num);
            }
            return timeNum;
//            return (int)Calculator.executeExpression(num);
//            return Integer.valueOf(matcher.group(1));
        }
        return 0;
    }

    private static Matcher getDateFormatMatcher(String dateString) {
        dateString = dateString.toUpperCase().trim();
        if(dateString.endsWith("S")) {
            dateString = dateString.substring(0, dateString.length()-1);
        }

        String patternStr = "^(-?\\d+)\\s((MILLISECOND|SECOND|MINUTE|HOUR|DAY|WEEK|MONTH|YEAR))";
        patternStr = "([0-9\\.+-/*()= ]+)\\s((MILLISECOND|SECOND|MINUTE|HOUR|DAY|WEEK|MONTH|YEAR))";
        Pattern pattern = Pattern.compile(patternStr);
        Matcher matcher = pattern.matcher(dateString);
        return matcher;
    }

    enum TimeType {
        NOW(0), MILLISECOND(14), SECOND(13), MINUTE(12), HOUR(10), DAY(5), WEEK(1), MONTH(2), YEAR(1);
        private int num;
        TimeType(int num) {
            this.num = num;
        }
    }

    public static void main(String[] args) {
//        System.out.println(stringToLocalDateTime("2020-12-01 23:26:06.666"));
        System.out.println(generateTimeStamp("10 minutes"));
        System.out.println(getTimeDifference("10 minutes"));

        System.out.println(generateCalendar(new Date(), "10 minutes"));
    }
}
