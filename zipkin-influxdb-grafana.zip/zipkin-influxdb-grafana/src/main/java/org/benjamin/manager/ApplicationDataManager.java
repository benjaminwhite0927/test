package org.benjamin.manager;

import org.benjamin.zipkin.SpanManagement;
import org.benjamin.zipkin.moudule.Span;
import org.benjamin.zipkin.moudule.ZipkinConstant;

import java.util.*;
import java.util.stream.Collectors;

public class ApplicationDataManager {
    public static final String STRING_KEY = "string.keys";
    public static final String LONG_KEY = "long.keys";
    public static final String DOUBLE_KEY = "double.keys";
    public static final String TIME_KEY = "time.keys";

    private final static String APPLICATION_KEY = "application";

    private final static String KEYS_COMBINE_LIST = "keys.combine.list";
    private final static String KEYS_COMBINE_PREFIX = "keys.combine.";

    private static Map<String, Map<String, List<String>>> influxDBData = new HashMap<>();
    private static Map<String, Map<String, List<String>>> combineDataKeys = new HashMap<>();

    public static Map<String, List<String>> getInfluxDataOfApplication(String application) {
        if (influxDBData.containsKey(application)) {
            return influxDBData.get(application);
        }
        Map<String, List<String>> data = new HashMap<>();
        Properties properties = FileManager.loadAllProperties(ConfigurationManager.CONFIGURATION_FOLDER + "/" + application + ".properties");

        data.put(STRING_KEY, Arrays.asList(properties.get(STRING_KEY).toString().split(",")));
        data.put(LONG_KEY, Arrays.asList(properties.get(LONG_KEY).toString().split(",")));
        data.put(DOUBLE_KEY, Arrays.asList(properties.get(DOUBLE_KEY).toString().split(",")));
        data.put(TIME_KEY, Arrays.asList(properties.get(TIME_KEY).toString().split(",")));
        influxDBData.put(application, data);
        return data;
    }

    // Generate standard data of spans
    public static Map<String, Object> generateInfluxDBDataFromSpan(String application, Span span) {
        Map<String, Object> datas = new HashMap<>();
        getInfluxDataOfApplication(application).forEach((key, values) -> {
            values.forEach(fieldName -> {
                datas.put(fieldName, SpanManagement.getAttribute(span, fieldName));
            });
        });
        combineData(application, datas);
        datas.put(APPLICATION_KEY, application);
        datas.put(ZipkinConstant.COUNT, 1);
        return datas;
    }

    private static void  combineData(String application, Map<String, Object> datas) {
        Properties properties = FileManager.loadAllProperties(ConfigurationManager.CONFIGURATION_FOLDER + "/" + application + ".properties");
        List<String> combineKeys = Arrays.asList(properties.get(KEYS_COMBINE_LIST).toString().split(","));

        combineKeys.forEach(key -> {
            String combineKey = KEYS_COMBINE_PREFIX + key;
            String value = SpanDataManager.getProperty(datas, key, properties.getProperty(combineKey));
            if (value.endsWith(":0")) {
                datas.put(key,value.replace(":0", ""));
            }
        });
    }

    public static List<Integer> getPCTs(String application) {
        Properties properties = FileManager.loadAllProperties(ConfigurationManager.CONFIGURATION_FOLDER + "/" + application + ".properties");
        return Arrays.asList(properties.get(ZipkinConstant.PTC).toString().split(",")).stream().map(Integer::valueOf).collect(Collectors.toList());
    }
}
