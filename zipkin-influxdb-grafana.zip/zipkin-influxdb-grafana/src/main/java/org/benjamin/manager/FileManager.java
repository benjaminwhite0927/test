package org.benjamin.manager;

import java.io.*;
import java.util.Properties;

public class FileManager {

    public static File getFile(String path) {
        ClassLoader classLoader = FileManager.class.getClassLoader();
        File file = new File(classLoader.getResource(path).getFile());
        return file;
    }

    public static Properties loadAllProperties(String propertiesFilePath) {
        Properties properties = new Properties();
        try {
            InputStream inputStream = new BufferedInputStream(new FileInputStream(getFile(propertiesFilePath)));
            properties.load(new InputStreamReader(inputStream, "UTF-8"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return properties;
    }
}
