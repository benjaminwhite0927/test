package org.benjamin.manager;

import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SpanDataManager {

    // Replace value of key by parameter keys and remove parameter keys
    public static String getProperty(Map<String, Object> datas, String key, String value) {
        String pattern = "\\$\\{.*?}";
        // 创建 Pattern 对象
        Pattern r = Pattern.compile(pattern);
        Matcher m = r.matcher(value);

        while (m.find()) {
            String findKey = m.group();
            System.out.println("1-->" + findKey);
            String fixKey = findKey.replaceAll("[${}]", "");
            System.out.println("2-->" + findKey);
            String findValue = datas.get(fixKey).toString();
            value = value.replaceAll(escapeExprSpecialWord(findKey), findValue);
            findKey = findKey.replace("${", "").replace("}", "");
            datas.remove(findKey);
            System.out.println("Find Key - " + findKey);
        }
        System.out.println("Put Key - " + key);
        datas.put(key, value);
        return value;
    }

    /**
     * 转义正则特殊字符 （$()*+.[]?\^{},|）
     */
    private static String escapeExprSpecialWord(String keyword) {
        if (keyword != null && keyword.length() > 0) {
            //{ "\\", "$", "(", ")", "*", "+", ".", "[", "]", "?", "^", "{", "}", "|" };
            String[] fbsArr = { "\\", "$", "(", ")", "*", "+", ".", "[", "]", "?", "^", "{", "}", "|" };
            for (String key : fbsArr) {
                if (keyword.contains(key)) {
                    keyword = keyword.replace(key, "\\" + key);
                }
            }
        }
        return keyword;
    }
}
