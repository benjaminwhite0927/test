package org.benjamin.manager;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.benjamin.influxdb.InfluxDBClientAPI;
import org.benjamin.zipkin.ZipkinStatistics;
import org.benjamin.zipkin.moudule.Span;
import org.benjamin.zipkin.moudule.ZipkinConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Sender implements Runnable{
    private String application;
    private ZipkinStatistics zipkinStatistics;
    private InfluxDBClientAPI influxDBClientAPI;
    private ScheduledExecutorService scheduler;
    private ScheduledFuture<?> timerHandle;

    private static final int MAX_POOL_SIZE = 1;
    private static final long SEND_INTERVAL = 5;
    private final static String SEND_DATA_INTERVAL = "send.data.interval";
    private final static String INFLUXDB_MEASUREMENT_SPANS = "influxdb.measurement.spans";

    private static final Logger log = LoggerFactory.getLogger(Sender.class);

    public Sender(String application) {
        this.application = application;
        zipkinStatistics = new ZipkinStatistics();
        influxDBClientAPI = new InfluxDBClientAPI();
    }

    public void  start() {
        this.timerHandle = scheduler.scheduleAtFixedRate(this, 0, SEND_INTERVAL, TimeUnit.SECONDS);
    }

    @Override
    public void run() {
        System.out.println("-----" + new Date());

        List<Span> spans = zipkinStatistics.getSpans(getSendDataInterval());
        spans.forEach(span -> {
            Map<String, Object> datas = ApplicationDataManager.generateInfluxDBDataFromSpan(application, span);
            // TODO - to define
            influxDBClientAPI.writeData(application, ConfigurationManager.getConfiguration(INFLUXDB_MEASUREMENT_SPANS), datas);
        });

        Map<String, Map<String, Map<String, Map<String, Map<String, Object>>>>> partitionStatistics = zipkinStatistics.regroupPartitionSpans(spans,ZipkinConstant.TOPIC_TAG, ZipkinConstant.PARTITION, ZipkinConstant.CONTENT_SIZE_TAG, ApplicationDataManager.getPCTs(application));
        writeDate(partitionStatistics, ZipkinConstant.PARTITION);

        Map<String, Map<String, Map<String, Map<String, Map<String, Object>>>>> brokerStatistics = zipkinStatistics.regroupPartitionSpans(spans,ZipkinConstant.TOPIC_TAG, ZipkinConstant.KIND, ZipkinConstant.CONTENT_SIZE_TAG, ApplicationDataManager.getPCTs(application));
        writeDate(brokerStatistics, ZipkinConstant.KIND);

        System.out.println("----------------------------------------");
    }

    public void writeDate(Map<String, Map<String, Map<String, Map<String, Map<String, Object>>>>> spanStatistics, String measurement) {
        //String measurement = "partition".equals(partition) ? partition : "kind";
        spanStatistics.forEach((broker, statistics) -> {
//            System.out.println("serviceName:: -> " + broker);

            statistics.forEach((topic, topicMap) -> {
//                System.out.println("Topic -> " + topic);
                topicMap.forEach((kind, kindMap) -> {
//                    System.out.println("Partition -- > " + kind);
                    kindMap.forEach((statistic, statisticMap) -> {
//                        System.out.println("Statistic --- > " + statistic);
                        if (ZipkinConstant.MESSAGE.equals(statistic)) {
                            statisticMap.forEach((key, value) -> {
//                                System.out.println("MMMM----------> Key - " + key + ": Value - " + value);
                                influxDBClientAPI.writeDoubleData(application, measurement, statisticMap);
                            });
                        } else {
                            statisticMap.forEach((key, value) -> {
                                System.out.println("----------> Key - " + key + ": Value - " + value);
                                influxDBClientAPI.writeData(application, measurement, statisticMap);
                            });
                        }
                    });
                });
            });
        });
    }

    public void setup() {
        influxDBClientAPI.init(application);
        scheduler = Executors.newScheduledThreadPool(MAX_POOL_SIZE);
    }

    public void destroy() {
        boolean cancelState = timerHandle.cancel(false);
        log.debug("Canceled state: {}", cancelState);
        scheduler.shutdown();
        try {
            scheduler.awaitTermination(30, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            log.error("Error waiting for end of scheduler");
            Thread.currentThread().interrupt();
        }
        influxDBClientAPI.close();
    }

    public static long getSendDataInterval() {
        return Long.valueOf(-DateTimeManager.getTimeDifference(ConfigurationManager.getConfiguration(SEND_DATA_INTERVAL)));
    }

    public static void main(String[] args) {
        Sender sender = new Sender("kafka");
        sender.setup();
        sender.start();
//        sender.run();

    }
}
