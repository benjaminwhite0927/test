package org.benjamin.zipkin;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.apache.commons.lang3.StringUtils;
import org.benjamin.manager.ConfigurationManager;
import org.benjamin.zipkin.moudule.Span;
import org.benjamin.zipkin.moudule.ZipkinConstant;

import java.util.*;
import java.util.stream.Collectors;

import static io.restassured.RestAssured.given;

public class ZipkinClientAPI {
    private final static String ZIPKIN_HOST = "zipkin.host";
    private final static String ZIPKIN_PORT = "zipkin.port";
    private final static String ZIPKIN_API = "zipkin.api";

    public ZipkinClientAPI() {
        this(ConfigurationManager.getConfiguration(ZIPKIN_HOST), Integer.valueOf(ConfigurationManager.getConfiguration(ZIPKIN_PORT)));
    }

    public ZipkinClientAPI(String zipkinHost, int port) {
        RestAssured.baseURI = "http://" + zipkinHost;
        RestAssured.port = port;
        RestAssured.basePath = "/api/v2";
    }

    public String get(long lookback) {
        return get(ConfigurationManager.getConfiguration(ZIPKIN_API), "", "", lookback);
    }

    public List<Span> getSpans(String stringJson) {
        List<List<Span>> spanLists = JSON.parseObject(stringJson, new TypeReference<List<List<Span>>>(){});
        List<Span> spans = new ArrayList<>();
        spanLists.stream().forEach(spanList -> spans.addAll(spanList));
        return spans.stream().collect(Collectors.toList());
    }

    public String get(String api, String serviceName, String annotationQuery, long lookback) {
        StringBuilder sb = new StringBuilder("/" + api + "?");
        boolean hasParameters = false;
        if(!StringUtils.isEmpty(serviceName)) {
            sb.append(ZipkinConstant.SERVICE_NAME + "=" + serviceName);
            hasParameters = true;
        }
        if (!StringUtils.isEmpty(annotationQuery)) {
            sb.append(ZipkinConstant.ANNOTATION_QUERY + "=" + annotationQuery);
            hasParameters = true;
        }
        if (lookback > 0) {
            sb.append(ZipkinConstant.LOOK_BACK + "=" + lookback);
            hasParameters = true;
        }
        Response response;
        if (hasParameters) {
            response = given().get(sb.toString());
        } else {
            response = given().get(sb.toString().replace("?", ""));
        }
        return response.getBody().asString();
    }

}
