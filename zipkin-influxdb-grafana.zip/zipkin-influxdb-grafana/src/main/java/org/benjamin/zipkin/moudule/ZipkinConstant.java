package org.benjamin.zipkin.moudule;

public class ZipkinConstant {
    public final static String SERVICE_NAME = "serviceName";
    public final static String ANNOTATION_QUERY = "annotationQuery";
    public final static String LOOK_BACK = "lookback";

    public final static String PARTITION = "partition";
    public final static String KIND = "kind";

    public final static String TOPIC_TAG = "kafka.topic";

    public final static String CONTENT_SIZE_TAG = "content.size";
    public final static String CONTENT_SIZE = "contentSize";


    public final static String TOPIC = "topic";
    public final static String STATISTICS = "statistics";
    public final static String DURATION = "duration";

    public final static String MESSAGE = "message";

    public final static String PTC = "pct";
    public final static String COUNT = "count";
    public final static String MIN = "min";
    public final static String MAX = "max";
    public final static String AVG = "avg";
    public final static String SUM = "sum";





}
