package org.benjamin.zipkin.moudule;

import java.util.Map;

public class Span {
    private String id;
    private String traceId;
    private String kind;
    private String name;
    private long timestamp;
    private long duration;
    private Endpoint localEndpoint;
    private Endpoint remoteEndpoint;
    private Map<String, String> tags;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getTraceId() {
        return traceId;
    }
    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }
    public String getKind() {
        return kind;
    }
    public void setKind(String kind) {
        this.kind = kind;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public long getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    public long getDuration() {
        return duration;
    }
    public void setDuration(long duration) {
        this.duration = duration;
    }
    public Endpoint getLocalEndpoint() {
        return localEndpoint;
    }
    public void setLocalEndpoint(Endpoint localEndpoint) {
        this.localEndpoint = localEndpoint;
    }
    public Endpoint getRemoteEndpoint() {
        return remoteEndpoint;
    }
    public void setRemoteEndpoint(Endpoint remoteEndpoint) {
        this.remoteEndpoint = remoteEndpoint;
    }
    public Map<String, String> getTags() {
        return tags;
    }
    public void setTags(Map<String, String> tags) {
        this.tags = tags;
    }

    @Override
    public String toString() {
        return "Span{" +
                "id='" + id + '\'' +
                ", traceId='" + traceId + '\'' +
                ", kind='" + kind + '\'' +
                ", name='" + name + '\'' +
                ", timestamp=" + timestamp +
                ", duration=" + duration +
                ", localEndpoint=" + localEndpoint +
                ", remoteEndpoint=" + remoteEndpoint +
                ", tags=" + tags +
                '}';
    }
}
