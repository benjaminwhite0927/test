package org.benjamin.zipkin;

import org.apache.commons.lang3.StringUtils;
import org.benjamin.zipkin.moudule.Endpoint;
import org.benjamin.zipkin.moudule.Span;

import java.lang.reflect.Field;

public class SpanManagement {
    public static String getAttribute(Span span, String attribute) {
        Class<Span> spanClass = (Class<Span>) span.getClass();
        try {
            Field field = spanClass.getDeclaredField(attribute);
            if (field != null) {
                field.setAccessible(true);
                return field.get(span).toString();
            }
        } catch (NoSuchFieldException | IllegalAccessException e) {
//            e.printStackTrace();
        }

        String value = getAttributeFromSpanEndPoint(span, attribute);
        if(!StringUtils.isEmpty(value)) {
            return value;
        }

        return span.getTags().get(attribute.replace("_", "."));
    }

    private static String getAttributeFromSpanEndPoint(Span span, String attribute) {
        String value = getAttribute(span.getLocalEndpoint(), attribute);
        if(!StringUtils.isEmpty(value)) {
            return value;
        }
        return getAttribute(span.getRemoteEndpoint(), attribute);
    }

    private static String getAttribute(Endpoint endpoint, String attribute) {
        Class<Endpoint> spanClass = (Class<Endpoint>) endpoint.getClass();
//        System.out.println(attribute);
        try {
            Field field = spanClass.getDeclaredField(attribute);
            if (field != null) {
                field.setAccessible(true);
                return field.get(endpoint).toString();
            }
        } catch (NoSuchFieldException | IllegalAccessException e) {
//            e.printStackTrace();
        }
        return "";
    }
}