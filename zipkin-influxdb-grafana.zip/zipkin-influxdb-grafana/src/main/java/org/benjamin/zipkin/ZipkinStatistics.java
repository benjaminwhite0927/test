package org.benjamin.zipkin;

import org.benjamin.zipkin.moudule.Span;
import org.benjamin.zipkin.moudule.ZipkinConstant;

import java.util.*;
import java.util.stream.Collectors;

public class ZipkinStatistics {

    ZipkinClientAPI zipkinClientAPI;

    public ZipkinStatistics() {
        zipkinClientAPI = new ZipkinClientAPI();
    }

    public List<Span> getSpans(long interval) {
        String jsonString = zipkinClientAPI.get(interval);
        return zipkinClientAPI.getSpans(jsonString);
    }

    /**
     *
     * @param partition - partition -> partition, otherwise -> kind
     * @return
     */
    // TODO - serviceName -> topic -> partition -> duration/content.size/message -> statistics
    // TODO - serviceName -> topic -> kind -> duration/content.size/message -> statistics
    // --> count / max / min / avg / sum / 90 / 95 / 99
    public Map<String, Map<String, Map<String, Map<String, Map<String, Object>>>>> regroupPartitionSpans(List<Span> spans, String topicTag, String partition, String contentSizeTag, List<Integer> pcts) {
        Map<String, Map<String, Map<String, Map<String, Map<String, Object>>>>> statistics = new HashMap<>();
        Map<String, List<Span>> serviceNameSpansMap = spans.parallelStream().collect(Collectors.groupingBy(
                span -> span.getLocalEndpoint().getServiceName())
        );
        serviceNameSpansMap.forEach((serviceName, bspans) -> {
            Map<String, Map<String, Map<String, Map<String, Object>>>> groupStatistics = partitionSpans(serviceName, bspans, topicTag, partition, contentSizeTag, pcts);
            statistics.put(serviceName, groupStatistics);
        });
        return statistics;
    }

    //TODO - serviceName -> topic -> partition -> consumer ->
    private Map<String, Map<String, Map<String, Map<String, Object>>>> partitionSpans(String serviceName, List<Span> spans, String topicTag, String partition, String contentSizeTag, List<Integer> pcts) {
        Map<String, Map<String, Map<String, Map<String, Object>>>> statistics = new HashMap<>();
        Map<String, List<Span>> topicSpansMap = spans.parallelStream().collect(Collectors.groupingBy(span -> span.getTags().get(topicTag)));
        topicSpansMap.forEach((k, v) -> {
            Map<String, Map<String, Map<String, Object>>> statisticsMap = new HashMap<>();
            Map<String, List<Span>> spansMap;
            String partitionOrKind;
            if (ZipkinConstant.PARTITION.equals(partition)) {
                partitionOrKind = ZipkinConstant.PARTITION;
                spansMap = v.parallelStream().filter(span -> span.getTags().containsKey(partition)).collect(Collectors.groupingBy(span -> span.getTags().get(partition)));
            } else {
                partitionOrKind = ZipkinConstant.KIND;
                spansMap = v.parallelStream().collect(Collectors.groupingBy(Span::getKind));
            }

            spansMap.forEach((key, value) -> {
                Map<String, Map<String, Object>> detailsStatistics = new HashMap<>();

                LongSummaryStatistics durationStatistics = value.parallelStream().collect(Collectors.summarizingLong(Span::getDuration));
                Map<String, Object> durationDatas = generatedStatistics(durationStatistics);
                pcts.forEach(pct -> {
                    durationDatas.put(ZipkinConstant.PTC + pct, (double)getSpanByDurationPCT(value, pct));
                });
                durationDatas.put(ZipkinConstant.SERVICE_NAME, serviceName);
                durationDatas.put(ZipkinConstant.STATISTICS, ZipkinConstant.DURATION);
                durationDatas.put(ZipkinConstant.TOPIC, k);
                durationDatas.put(partitionOrKind, key);
                detailsStatistics.put(ZipkinConstant.DURATION, durationDatas);

                DoubleSummaryStatistics messageStatistics = value.parallelStream().collect(Collectors.summarizingDouble(span -> 1 / (double)span.getDuration()));
                Map<String, Object> messageDatas = generatedDoubleStatistics(messageStatistics);
                pcts.forEach(pct -> {
                    messageDatas.put(ZipkinConstant.PTC + pct, getSpanByMessagePCT(value, pct));
                });
                messageDatas.put(ZipkinConstant.STATISTICS, ZipkinConstant.MESSAGE);
                messageDatas.put(ZipkinConstant.SERVICE_NAME, serviceName);
                messageDatas.put(ZipkinConstant.TOPIC, k);
                messageDatas.put(partitionOrKind, key);
                detailsStatistics.put(ZipkinConstant.MESSAGE, messageDatas);


                LongSummaryStatistics contentSizeStatistics = value.parallelStream().map(span -> Long.valueOf(span.getTags().get(contentSizeTag)))
                        .collect(Collectors.summarizingLong(Long::valueOf));
                Map<String, Object> contentSizeDatas = generatedStatistics(contentSizeStatistics);
                pcts.forEach(pct -> {
                    contentSizeDatas.put(ZipkinConstant.PTC + pct, (double)getSpanByContentSizePCT(value, pct, contentSizeTag));
                });
                contentSizeDatas.put(ZipkinConstant.STATISTICS, ZipkinConstant.CONTENT_SIZE);
                contentSizeDatas.put(ZipkinConstant.SERVICE_NAME, serviceName);
                contentSizeDatas.put(ZipkinConstant.TOPIC, k);
                contentSizeDatas.put(partitionOrKind, key);
                detailsStatistics.put(ZipkinConstant.CONTENT_SIZE, contentSizeDatas);

                statisticsMap.put(key, detailsStatistics);
            });

            statistics.put(k, statisticsMap);
        });

        return statistics;
    }


    private Map<String, Object> generatedStatistics(LongSummaryStatistics statistics) {
        Map<String, Object> statisticsMap = new HashMap<>();
        statisticsMap.put(ZipkinConstant.COUNT, statistics.getCount());
        statisticsMap.put(ZipkinConstant.MIN, statistics.getMin());
        statisticsMap.put(ZipkinConstant.MAX, statistics.getMax());
        statisticsMap.put(ZipkinConstant.AVG, statistics.getAverage());
        statisticsMap.put(ZipkinConstant.AVG, statistics.getSum());
        return statisticsMap;
    }
    private Map<String, Object> generatedDoubleStatistics(DoubleSummaryStatistics statistics) {
        Map<String, Object> statisticsMap = new HashMap<>();
        statisticsMap.put(ZipkinConstant.COUNT, statistics.getCount());
        statisticsMap.put(ZipkinConstant.MIN, statistics.getMin());
        statisticsMap.put(ZipkinConstant.MAX, statistics.getMax());
        statisticsMap.put(ZipkinConstant.AVG, statistics.getAverage());
        statisticsMap.put(ZipkinConstant.SUM, statistics.getSum());
        return statisticsMap;
    }

    private double getSpanByMessagePCT(List<Span> spans, int pct) {
        spans = spans.parallelStream().sorted(Comparator.comparing(span -> 1/(double)span.getDuration())).collect(Collectors.toList());
        int index = spans.size() * pct / 100;
        return 1/(double)spans.get(index).getDuration();
    }

    private long getSpanByDurationPCT(List<Span> spans, int pct) {
        spans = spans.parallelStream().sorted(Comparator.comparing(Span::getDuration)).collect(Collectors.toList());
        int index = spans.size() * pct / 100;
        return spans.get(index).getDuration();
    }

    private long getSpanByContentSizePCT(List<Span> spans, int pct, String contentSizeTage) {
        spans = spans.parallelStream().sorted(Comparator.comparing(span -> Long.valueOf(span.getTags().get(contentSizeTage)))).collect(Collectors.toList());
        int index = spans.size() * pct / 100;
        return Long.valueOf(spans.get(index).getTags().get(contentSizeTage));
    }

}
