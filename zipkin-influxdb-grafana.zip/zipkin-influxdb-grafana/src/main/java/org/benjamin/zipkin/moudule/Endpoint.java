package org.benjamin.zipkin.moudule;

public class Endpoint {
    private String serviceName;
    private String ipv4;
    private String ipv6;
    private int port;

    public String getServiceName() {
        return serviceName;
    }
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }
    public String getIpv4() {
        return ipv4;
    }
    public void setIpv4(String ipv4) {
        this.ipv4 = ipv4;
    }
    public String getIpv6() {
        return ipv6;
    }
    public void setIpv6(String ipv6) {
        this.ipv6 = ipv6;
    }
    public int getPort() {
        return port;
    }
    public void setPort(int port) {
        this.port = port;
    }

    @Override
    public String toString() {
        return "Endpoint{" +
                "serviceName='" + serviceName + '\'' +
                ", ipv4='" + ipv4 + '\'' +
                ", ipv6='" + ipv6 + '\'' +
                ", port=" + port +
                '}';
    }
}
